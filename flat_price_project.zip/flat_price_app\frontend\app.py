"""
Flat Price Prediction — Streamlit Frontend
Run with:  python -m streamlit run app.py
Requires backend API running at http://localhost:8000
"""

import streamlit as st
import requests
import pandas as pd

API_URL = "http://localhost:8000"

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Flat Price Predictor",
    page_icon="🏠",
    layout="centered",
)

# ---------------------------------------------------------------------------
# Fetch model info from backend (cached)
# ---------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def get_model_info() -> dict | None:
    try:
        r = requests.get(f"{API_URL}/info", timeout=5)
        r.raise_for_status()
        return r.json()
    except Exception:
        return None


info = get_model_info()

# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------
st.title("🏠 Flat Price Predictor")
st.markdown("Predict flat prices for **Lonavala**, **Karjat**, and **Khandala** using a Linear Regression model.")
st.divider()

# Backend connectivity warning
if info is None:
    st.error(
        "**Backend API is not reachable.**  \n"
        "Please start it first:  \n"
        "`cd flat_price_app/backend && python -m uvicorn api:app --reload --port 8000`"
    )
    st.stop()

# ---------------------------------------------------------------------------
# Model info sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("Model Info")
    st.metric("Algorithm",     info.get("algorithm", "—"))
    st.metric("R² Score",      info.get("r2_score",  "—"))
    st.metric("Training Rows", info.get("training_rows", "—"))
    st.markdown("---")
    st.caption("**Valid Locations**")
    for p in info.get("valid_places", []):
        st.markdown(f"- {p}")
    st.markdown("---")
    st.caption(
        f"Area range in training data:  \n"
        f"**{info.get('area_min', '?'):,} – {info.get('area_max', '?'):,} sq ft**"
    )

# ---------------------------------------------------------------------------
# Prediction form
# ---------------------------------------------------------------------------
st.subheader("Enter Flat Details")

col1, col2 = st.columns(2)

with col1:
    place = st.selectbox(
        "Location",
        options=info.get("valid_places", ["Karjat", "Khandala", "Lonavala"]),
        help="Select the location of the flat.",
    )

with col2:
    area = st.number_input(
        "Area (sq ft)",
        min_value=500,
        max_value=10000,
        value=2800,
        step=100,
        help="Enter the flat area in square feet.",
    )

predict_btn = st.button("Predict Price", type="primary", use_container_width=True)

# ---------------------------------------------------------------------------
# Prediction result
# ---------------------------------------------------------------------------
if predict_btn:
    with st.spinner("Getting prediction..."):
        try:
            response = requests.post(
                f"{API_URL}/predict",
                json={"place": place, "area": area},
                timeout=10,
            )
            response.raise_for_status()
            result = response.json()

            price = result["predicted_price"]

            st.divider()
            st.subheader("Prediction Result")

            r1, r2_col, r3 = st.columns(3)
            r1.metric("Location",      result["place"])
            r2_col.metric("Area",      f"{result['area']:,.0f} sq ft")
            r3.metric("Predicted Price", f"Rs. {price} L")

            st.success(f"Estimated flat price in **{result['place']}** for **{area:,} sq ft** is **Rs. {price} Lakhs**.")

        except requests.exceptions.HTTPError as e:
            detail = e.response.json().get("detail", str(e)) if e.response else str(e)
            st.error(f"Prediction failed: {detail}")
        except Exception as e:
            st.error(f"Unexpected error: {e}")

# ---------------------------------------------------------------------------
# Training data table
# ---------------------------------------------------------------------------
st.divider()
st.subheader("Training Data Reference")

training_data = pd.DataFrame({
    "Location": ["Lonavala", "Lonavala", "Lonavala", "Karjat", "Karjat", "Khandala", "Khandala", "Khandala"],
    "Area (sq ft)": [2600, 3000, 3200, 2600, 2800, 2600, 2900, 3200],
    "Price (Lakhs)": [5.5, 5.65, 6.1, 4.5, 5.0, 6.0, 6.5, 6.8],
})
st.dataframe(training_data, use_container_width=True, hide_index=True)

# ---------------------------------------------------------------------------
# Price trend chart
# ---------------------------------------------------------------------------
st.subheader("Price Trend by Location")
chart_data = training_data.rename(columns={"Area (sq ft)": "Area", "Price (Lakhs)": "Price"})

for loc in training_data["Location"].unique():
    loc_df = training_data[training_data["Location"] == loc][["Area (sq ft)", "Price (Lakhs)"]].set_index("Area (sq ft)")
    st.line_chart(loc_df, use_container_width=True, height=200)
    st.caption(f"Price trend — {loc}")
